<?php
include("include_homework.php");

$register=new databaseuse("localhost","qwerrtty","","project");
$register->sql_query("set names utf8");
$register->sql_query("SET CHARACTER_SET_RESULTS=UTF8;");
$result=$register->sql_query("select  * from Carpool_data where
	 1");
	 
	 
?>






<!DOCTYPE html>

<html lang="zh">
<head >
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <!-- 最新編譯和最佳化的 CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">

<!-- 選擇性佈景主題 -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">

<!-- 最新編譯和最佳化的 JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

<style type="text/css">
  
    .indexWrap
    {
        margin-left:200px;
        margin-top:150px;
        border-style:groove;
         width:500px;
         height:500px;
         padding:5px;
    
    }
    .search
    {
        border: 1px groove;
        width:305px auto;
        height:35px auto;
        float:left
    }
</style>
</head>  
<body style="font-family:Microsoft JhengHei; ">
  <ul class="nav nav-tabs"  style="float:right">
      
        <li><a  href="carpool_index.html">首頁</a></li>
        <li><a  href="carpool_register.html">註冊</a></li>
        <li><a  href="carpool_login.html">登入</a></li>
        <li><a  href="carpool_publish.html" style="color:green">刊登</a></li>
    </ul>


<br>
  <div class="search">
         <input type="text" name="a" style="width:250px;height:35px;" 
         placeholder="要到哪呢?"/>
         
    </div>
<div class="indexWrap" >
  	<ul class="list-group" >
	<?php while ($row =$register->sql_fetch_array($result)) : ?>
		<li style=" width:400px;height:90px;" class="list-group-item">
			<a href="carpool_mycarpool.html?id=<?php echo $row["ID"] ?>"> 
			<p ><?php echo $row["date"] . "  " . $row["time"] ?> 
			<font style="float:right;font-size:1.5em"><?php echo $row['Account']?></font>
			</p>
			<p style="font-size:1.0em"><?php echo $row["pointA"] . " 到 " . $row["pointB"] ?></p>
		    <p><?php echo "還剩".$row['lack']."個空位"?></p>
		    </a>
	 	</li>
	<?php endwhile ?>
	</ul>
    
</div>
</body>
</html>