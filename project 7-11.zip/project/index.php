<?php

echo "哈哈你這個87";


?>
<html>
<head >
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>
    </html>