<?php

include("include_homework.php");


$register=new databaseuse("localhost","qwerrtty","","project");
$register->connect();
/*$register->sql_query("INSERT INTO`Carpool_data`
Values('{$_POST['Account']}',0
'{$_POST['pointA']}',
'{$_POST['pointB']}',
'{$_POST['date']}',
'{$_POST['time']}',
'{$_POST['lack']}',
'{$_POST['price']}'");*/
$register->sql_query("set names utf8");
$row=$register->sql_fetch_array($register->sql_query("SELECT MAX( ID ) AS ID FROM Carpool_data"));
$ID=$row['ID']+1;
$register->sql_query("INSERT INTO 
`Carpool_data`
(  `Account` ,  `ID` ,  `pointA` ,  `pointB` ,  `date` ,  `time` , `lack` ,  `price` ) 
VALUES (
'{$_POST['Account']}','{$ID}' , 
'{$_POST['pointA']}',
'{$_POST['pointB']}',
'{$_POST['date']}',
'{$_POST['time']}',
'{$_POST['lack']}',
'{$_POST['price']}'
)");
$register->sql_query("INSERT INTO `Carpool_data_plus`
(`ID`, `food`, `pet`, `baggage`, `smoke`, `remark`)
VALUES(
'{$ID}',
'{$_POST['food']}',
'{$_POST['pet']}',
'{$_POST['baggage']}',
'{$_POST['smoke']}',
'{$_POST['remark']}')");


?>