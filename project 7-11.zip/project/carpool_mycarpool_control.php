<?php
if (! isset ( $_GET ["id"] ))
	die ( "Parameter id not found." );

$id = $_GET ["id"];
if (! is_numeric ( $id ))
	die ( "id not a number." );
	include("include_homework.php");
	 $register=new databaseuse("localhost","qwerrtty","","project");
	 $register->sql_query("set names utf8");
	 $register->sql_query("SET CHARACTER_SET_RESULTS=UTF8;");
	 $result=$register->sql_query("select  * from Carpool_data where
	 ID='{$_GET['id']}'");
	 $row=$register->sql_fetch_array($result);
	  $result_plus=$register->sql_query("select  * from Carpool_data_plus where
	 ID='{$_GET['id']}'");
	 $row_plus=$register->sql_fetch_array($result_plus);
	 
	 $row2=array("Account"=>$row['Account'],
	 "ID"=>$row['ID'],
	 "pointA"=>$row['pointA'],
	 "pointB"=>$row['pointB'],
	 "date"=>$row['date'],
	 "time"=>$row['time'],
	 "lack"=>$row['lack'],
	 "price"=>$row['price'],
	 "food"=>$row_plus['food'],
	 "pet"=>$row_plus['pet'],
	 "baggage"=>$row_plus["baggage"],
	 "smoke"=>$row_plus['smoke'],
	 "remark"=>$row_plus['remark']);
	 echo json_encode($row2,JSON_UNESCAPED_UNICODE);
	
	
	
	
	
	
?>