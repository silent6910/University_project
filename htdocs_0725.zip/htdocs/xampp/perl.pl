#!"C:\xampp\perl\bin\perl.exe"

print "Content-Type: text/html\n\n";
print "OK";
